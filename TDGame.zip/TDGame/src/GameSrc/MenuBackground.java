package GameSrc;

import jgame.GSprite;
import jgame.ImageCache;

public class MenuBackground extends GSprite {
	
	public MenuBackground() {
		
		super(ImageCache.getImage("PlayArea.jpg"));

	}
}
