package GameSrc;

import java.awt.Color;

import jgame.GContainer;

public class informationArea extends GContainer {

	public informationArea() {
		setSize(900, 100);
		setBackgroundColor(Color.darkGray);
	}
}
