package GameSrc;

import java.awt.image.BufferedImage;

import jgame.GSprite;

public abstract class Enemy extends GSprite {
	
	public Enemy(BufferedImage image) {
		super(image.getScaledInstance(80, 80, 0));
	}
	
	public abstract double getX();
	
	public abstract double getY();
}
