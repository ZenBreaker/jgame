package GameSrc;

import jgame.Context;
import jgame.GContainer;
import jgame.GObject;
import jgame.ImageCache;
import jgame.controller.MouseLocationController;
import jgame.listener.LocalClickListener;

public class TGLevelOneView extends GContainer {

	private static levelOnePlayArea l1pa = new levelOnePlayArea();
	private menuArea ma = new menuArea();
	private informationArea ia = new informationArea();

	public boolean settingTurret = false;
	public static boolean dead = false;

	public TGLevelOneView() {
		setSize(900, 700);

		l1pa.setAnchorTopLeft();
		l1pa.setLocation(100, 0);
		add(l1pa);

		ma.setAnchorTopLeft();
		ma.setLocation(0, 0);
		add(ma);

		ia.setAnchorTopLeft();
		ia.setLocation(0, 600);
		add(ia);
	}

	public void initializeTurret(int tn) {
		if (settingTurret) {
			return;
		}
		settingTurret = true;

		Turret t = chooseTurret(tn);
		TGLevelOneView.l1pa.addAt(t, 100, 100);

		final MouseLocationController mlc = new MouseLocationController();
		t.addController(mlc);

		final LocalClickListener dropListener = new LocalClickListener() {
			@Override
			public void invoke(GObject target, Context context) {
				target.removeController(mlc);
				target.removeListener(this);
				settingTurret = false;
				spawnEnemy();
			}
		};
		t.addListener(dropListener);
	}

	public static Enemy spawnEnemy() {
		EnemyOne enemyOne = new EnemyOne(ImageCache.getImage("EnemyOne.png"));
		l1pa.addAt(enemyOne, enemyOne.getX(), enemyOne.getY());
		return enemyOne;
	}

	public Turret chooseTurret(int turretNumber) {
		switch (turretNumber) {
		case 0:
			return new TurretOne(ImageCache.getImage("TurretOne.png"));

		case 1:
			return new TurretTwo(ImageCache.getImage("TurretTwo.png"));

		case 2:
			return new TurretThree(ImageCache.getImage("TurretThree.png"));

		case 3:
			return new TurretFour(ImageCache.getImage("TurretFour.png"));

		case 4:
			return new TurretFive(ImageCache.getImage("TurretFive.png"));

		default:
			return null;
		}
	}
}
